<?php
require 'vendor/autoload.php';
putenv('DB_HOST=127.0.0.1');
putenv('DB_PORT=3306');
putenv('DB_DATABASE=db_presensi_smkalfarizi');
putenv('DB_USERNAME=root');
putenv('DB_PASSWORD=');

require 'app/Config/Database.php';

$db = App\Config\Database::getConnection();
$res = $db->query('SHOW COLUMNS FROM presensi_gerbang_siswa')->fetchAll();
print_r($res);
