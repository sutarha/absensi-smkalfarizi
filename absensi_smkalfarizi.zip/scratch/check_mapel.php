<?php
require_once __DIR__ . '/../app/Config/Database.php';

$db = App\Config\Database::getConnection();

echo "=== TABLE MATA_PELAJARAN ===\n";
foreach ($db->query("DESCRIBE mata_pelajaran")->fetchAll(PDO::FETCH_ASSOC) as $c) {
    echo $c['Field'] . " | " . $c['Type'] . " | Null: " . $c['Null'] . " | Default: " . ($c['Default'] ?? 'NULL') . "\n";
}

echo "\n=== EXISTING MAPEL SAMPLE ===\n";
foreach ($db->query("SELECT * FROM mata_pelajaran LIMIT 10")->fetchAll(PDO::FETCH_ASSOC) as $m) {
    echo "{$m['id']} | {$m['kode_mapel']} | {$m['nama_mapel']} | Kelompok: {$m['kelompok']} | Tingkat: {$m['tingkat']}\n";
}
