<?php
require_once __DIR__ . '/../app/Config/Database.php';

use App\Config\Database;

$db = Database::getConnection();
echo "=== COLUMNS OF JADWAL_PELAJARAN ===\n";
foreach ($db->query("DESCRIBE jadwal_pelajaran")->fetchAll(PDO::FETCH_ASSOC) as $col) {
    echo "{$col['Field']} | {$col['Type']} | Null: {$col['Null']} | Key: {$col['Key']} | Default: {$col['Default']}\n";
}

echo "\n=== EXISTING JADWAL SAMPLE ===\n";
foreach ($db->query("SELECT j.*, k.nama_kelas, g.nama_lengkap FROM jadwal_pelajaran j JOIN kelas k ON k.id=j.kelas_id JOIN guru g ON g.id=j.guru_id LIMIT 5")->fetchAll(PDO::FETCH_ASSOC) as $j) {
    echo "[{$j['id']}] {$j['hari']} | {$j['jam_mulai']} - {$j['jam_selesai']} | Kelas: {$j['nama_kelas']} | Mapel: {$j['nama_mapel']} | Guru: {$j['nama_lengkap']}\n";
}
