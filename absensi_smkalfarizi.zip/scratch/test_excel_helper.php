<?php
require_once __DIR__ . '/../app/Helpers/ExcelHelper.php';

use App\Helpers\ExcelHelper;

$headers = ['NISN', 'Nama Siswa', 'Kelas', 'Tempat Lahir', 'Tanggal Lahir'];
$rows = [
    ['0087654321', 'Fathir Ahmad', 'X PPLG 1', 'Bandung', '2008-05-15'],
    ['0087654322', 'Rania Azzahra', 'X PPLG 1', 'Jakarta', '2008-08-20']
];

$xlsxContent = ExcelHelper::createXlsx("Data Pokok Siswa", $headers, $rows);
echo "XLSX size: " . strlen($xlsxContent) . " bytes\n";

$tmp = tempnam(sys_get_temp_dir(), 'test_') . '.xlsx';
file_put_contents($tmp, $xlsxContent);

$parsed = ExcelHelper::parse($tmp);
echo "Parsed " . count($parsed) . " rows:\n";
print_r($parsed);

@unlink($tmp);
echo "SUCCESS!\n";
