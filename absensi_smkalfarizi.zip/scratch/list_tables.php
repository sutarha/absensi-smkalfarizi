<?php
require_once __DIR__ . '/../app/Config/Database.php';

use App\Config\Database;

$db = Database::getConnection();
echo "=== ALL TABLES ===\n";
foreach ($db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN) as $tbl) {
    echo "- {$tbl}\n";
}
