<?php
require_once __DIR__ . '/../app/Config/Database.php';

use App\Config\Database;

try {
    $db = Database::getConnection();
    echo "Creating table kelas_mapel...\n";
    $db->exec("
        CREATE TABLE IF NOT EXISTS `kelas_mapel` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `kelas_id` INT NOT NULL,
            `mapel_id` INT NOT NULL,
            `guru_id` INT NOT NULL,
            `alokasi_jp` INT NOT NULL DEFAULT 2,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            CONSTRAINT `fk_km_kelas` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE CASCADE,
            CONSTRAINT `fk_km_mapel` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran` (`id`) ON DELETE CASCADE,
            CONSTRAINT `fk_km_guru` FOREIGN KEY (`guru_id`) REFERENCES `guru` (`id`) ON DELETE CASCADE,
            UNIQUE KEY `uk_kelas_mapel` (`kelas_id`, `mapel_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    echo "SUCCESS: Table kelas_mapel created successfully!\n";
    
    // Verify
    foreach ($db->query("DESCRIBE kelas_mapel")->fetchAll(PDO::FETCH_ASSOC) as $col) {
        echo "{$col['Field']} | {$col['Type']} | Null: {$col['Null']} | Key: {$col['Key']} | Default: {$col['Default']}\n";
    }
} catch (\Throwable $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
