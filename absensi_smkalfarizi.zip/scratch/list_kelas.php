<?php
require_once __DIR__ . '/../app/Config/Database.php';

use App\Config\Database;

$db = Database::getConnection();
echo "=== KELAS LIST ===\n";
foreach ($db->query("SELECT id, nama_kelas, tingkat, jurusan FROM kelas")->fetchAll(PDO::FETCH_ASSOC) as $k) {
    echo "[{$k['id']}] {$k['nama_kelas']} (Tingkat: {$k['tingkat']} - {$k['jurusan']})\n";
}
