<?php
/**
 * Test script to generate and parse XLSX
 */

function colLetter($colIndex) {
    $letter = '';
    while ($colIndex >= 0) {
        $letter = chr($colIndex % 26 + 65) . $letter;
        $colIndex = intval($colIndex / 26) - 1;
    }
    return $letter;
}

function createXlsxTest($filename, $headers, $rows) {
    $zip = new ZipArchive();
    if ($zip->open($filename, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new Exception("Cannot create zip");
    }

    // [Content_Types].xml
    $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>');

    // _rels/.rels
    $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>');

    // xl/_rels/workbook.xml.rels
    $zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>');

    // xl/workbook.xml
    $zip->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="Data Pokok Siswa" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>');

    // sheet1.xml
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
    $xml .= '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';
    $xml .= '<sheetData>';

    // Header row
    $r = 1;
    $xml .= '<row r="' . $r . '">';
    foreach ($headers as $c => $h) {
        $cellRef = colLetter($c) . $r;
        $escaped = htmlspecialchars((string)$h, ENT_XML1, 'UTF-8');
        $xml .= '<c r="' . $cellRef . '" t="inlineStr"><is><t>' . $escaped . '</t></is></c>';
    }
    $xml .= '</row>';

    // Data rows
    foreach ($rows as $row) {
        $r++;
        $xml .= '<row r="' . $r . '">';
        foreach (array_values($row) as $c => $val) {
            $cellRef = colLetter($c) . $r;
            $escaped = htmlspecialchars((string)$val, ENT_XML1, 'UTF-8');
            $xml .= '<c r="' . $cellRef . '" t="inlineStr"><is><t>' . $escaped . '</t></is></c>';
        }
        $xml .= '</row>';
    }

    $xml .= '</sheetData>';
    $xml .= '</worksheet>';

    $zip->addFromString('xl/worksheets/sheet1.xml', $xml);
    $zip->close();
}

function parseXlsxTest($filename) {
    $zip = new ZipArchive();
    if ($zip->open($filename) !== true) {
        throw new Exception("Cannot open xlsx file");
    }

    // Shared strings if any
    $sharedStrings = [];
    $ssContent = $zip->getFromName('xl/sharedStrings.xml');
    if ($ssContent !== false) {
        $xml = simplexml_load_string($ssContent);
        if ($xml && isset($xml->si)) {
            foreach ($xml->si as $si) {
                if (isset($si->t)) {
                    $sharedStrings[] = (string)$si->t;
                } elseif (isset($si->r)) {
                    $t = '';
                    foreach ($si->r as $r) {
                        $t .= (string)$r->t;
                    }
                    $sharedStrings[] = $t;
                } else {
                    $sharedStrings[] = '';
                }
            }
        }
    }

    // Sheet1
    $sheetContent = $zip->getFromName('xl/worksheets/sheet1.xml');
    $zip->close();

    if ($sheetContent === false) {
        throw new Exception("Cannot read sheet1.xml");
    }

    $xml = simplexml_load_string($sheetContent);
    $data = [];

    foreach ($xml->sheetData->row as $row) {
        $rowData = [];
        foreach ($row->c as $cell) {
            $type = (string)$cell['t'];
            $val = '';
            if ($type === 'inlineStr') {
                $val = (string)$cell->is->t;
            } elseif ($type === 's') {
                $idx = (int)$cell->v;
                $val = $sharedStrings[$idx] ?? '';
            } else {
                $val = (string)$cell->v;
            }
            $rowData[] = $val;
        }
        $data[] = $rowData;
    }

    return $data;
}

$testFile = __DIR__ . '/test_output.xlsx';
$headers = ['NISN', 'Nama Siswa', 'Kelas', 'Jenis Kelamin'];
$rows = [
    ['0081234501', 'Ahmad Dani', 'X PPLG 1', 'L'],
    ['0081234502', 'Siti Fatimah', 'X PPLG 1', 'P']
];

createXlsxTest($testFile, $headers, $rows);
echo "Created: $testFile (size: " . filesize($testFile) . " bytes)\n";

$parsed = parseXlsxTest($testFile);
echo "Parsed " . count($parsed) . " rows:\n";
print_r($parsed);

@unlink($testFile);
