<?php
require 'vendor/autoload.php';
putenv('DB_HOST=127.0.0.1');
putenv('DB_PORT=3306');
putenv('DB_DATABASE=db_presensi_smkalfarizi');
putenv('DB_USERNAME=root');
putenv('DB_PASSWORD=');

require 'app/Config/Database.php';

use App\Config\Database;

$db = Database::getConnection();
$siswa = $db->query('SELECT nisn, tanggal_lahir FROM siswa LIMIT 1')->fetch();
if (!$siswa) {
    die("No siswa found.");
}

$ch = curl_init('http://localhost:8000/api/v1/siswa/login');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'nisn' => $siswa['nisn'],
    'tanggal_lahir' => $siswa['tanggal_lahir']
]));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
$resp = curl_exec($ch);
curl_close($ch);

echo "Login response:\n$resp\n";

$data = json_decode($resp, true);
if (!empty($data['token'])) {
    $token = $data['token'];
    
    $ch2 = curl_init('http://localhost:8000/api/v1/siswa/dashboard');
    curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch2, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $token,
        'Content-Type: application/json'
    ]);
    $resp2 = curl_exec($ch2);
    curl_close($ch2);
    
    echo "Dashboard response:\n$resp2\n";
}
