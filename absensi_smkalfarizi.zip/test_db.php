<?php
require 'vendor/autoload.php';
putenv('DB_HOST=127.0.0.1');
putenv('DB_PORT=3306');
putenv('DB_DATABASE=db_presensi_smkalfarizi');
putenv('DB_USERNAME=root');
putenv('DB_PASSWORD=');

require 'app/Config/Database.php';

use App\Config\Database;

$db = Database::getConnection();
try {
    $stmt = $db->prepare('SELECT COUNT(*) FROM notifikasi_siswa WHERE siswa_id = 1 AND is_read = 0');
    $stmt->execute();
    echo "notifikasi_siswa OK\n";
} catch (Exception $e) {
    echo "ERROR notifikasi: " . $e->getMessage() . "\n";
}

try {
    $stmt = $db->prepare("
        SELECT jp.jam_mulai, jp.jam_selesai, mp.nama_mapel, g.nama_lengkap AS nama_guru
        FROM   jadwal_pelajaran jp
        JOIN   mata_pelajaran mp ON mp.id = jp.mapel_id
        JOIN   guru g            ON g.id  = jp.guru_id
        JOIN   siswa s           ON s.kelas_id = jp.kelas_id
        WHERE  s.id   = 1
          AND  jp.hari = 'SENIN'
        ORDER  BY jp.jam_mulai ASC
    ");
    $stmt->execute();
    echo "jadwal_pelajaran OK\n";
} catch (Exception $e) {
    echo "ERROR jadwal: " . $e->getMessage() . "\n";
}
