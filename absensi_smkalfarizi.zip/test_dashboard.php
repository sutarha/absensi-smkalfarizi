<?php
$ch = curl_init('http://localhost:8000/api/v1/siswa/login');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['nisn'=>'0071234501','tanggal_lahir'=>'2005-01-01']));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
$res = curl_exec($ch);
$token = json_decode($res)->token;

curl_setopt($ch, CURLOPT_URL, 'http://localhost:8000/api/v1/siswa/dashboard');
curl_setopt($ch, CURLOPT_POST, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $token]);
echo curl_exec($ch);
