<?php
require 'vendor/autoload.php';
putenv('DB_HOST=127.0.0.1');
putenv('DB_PORT=3306');
putenv('DB_DATABASE=db_presensi_smkalfarizi');
putenv('DB_USERNAME=root');
putenv('DB_PASSWORD=');

require 'app/Config/Database.php';

use App\Config\Database;

$db = Database::getConnection();
try {
    $stmt = $db->prepare("
            SELECT
                COUNT(*) AS total_hari,
                SUM(CASE WHEN status_kehadiran = 'HADIR' THEN 1 ELSE 0 END)  AS hadir,
                SUM(CASE WHEN status_kehadiran = 'TELAT' THEN 1 ELSE 0 END)  AS telat,
                SUM(CASE WHEN status_kehadiran = 'IZIN'  THEN 1 ELSE 0 END)  AS izin,
                SUM(CASE WHEN status_kehadiran = 'SAKIT' THEN 1 ELSE 0 END)  AS sakit,
                SUM(CASE WHEN status_kehadiran = 'ALPHA' THEN 1 ELSE 0 END)  AS alpha
            FROM presensi_gerbang_siswa
            WHERE siswa_id = 1
              AND MONTH(tanggal) = MONTH(CURDATE())
              AND YEAR(tanggal)  = YEAR(CURDATE())
        ");
    $stmt->execute();
    echo "presensi_gerbang_siswa OK\n";
} catch (Exception $e) {
    echo "ERROR presensi: " . $e->getMessage() . "\n";
}
