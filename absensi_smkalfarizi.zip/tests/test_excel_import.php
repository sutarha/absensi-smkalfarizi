<?php
// tests/test_excel_import.php - Verifikasi Import & Download Template Excel Dapodik (.xlsx)
require_once __DIR__ . '/../app/Config/App.php';
require_once __DIR__ . '/../app/Config/Database.php';
require_once __DIR__ . '/../app/Helpers/ExcelHelper.php';
require_once __DIR__ . '/../app/Helpers/DapodikHelper.php';
require_once __DIR__ . '/../app/Models/BukuInduk.php';
require_once __DIR__ . '/../app/Models/Siswa.php';

use App\Helpers\ExcelHelper;
use App\Helpers\DapodikHelper;
use App\Models\BukuInduk;
use App\Models\Siswa;

echo "=== TEST SUITE: IMPORT EXCEL (.XLSX) BUKU INDUK DAPODIK ===\n";

// 1. Uji Pembuatan Template Excel (.xlsx) Asli
$xlsxContent = DapodikHelper::getExcelTemplateContent();
assert(strlen($xlsxContent) > 1000, "Ukuran template XLSX harus valid (> 1KB)");
echo "✓ 1. Berhasil menghasilkan berkas binary Microsoft Excel (.xlsx) (" . strlen($xlsxContent) . " bytes)\n";

// 2. Simpan Sementara & Uji Parser
$tempPath = __DIR__ . '/temp_test.xlsx';
file_put_contents($tempPath, $xlsxContent);

$parsedRows = DapodikHelper::parseFile($tempPath, 'temp_test.xlsx');
assert(count($parsedRows) >= 2, "Harus terdapat minimal 2 baris data contoh");
assert($parsedRows[0]['nisn'] === '0081234567', "NISN dengan leading zero harus tetap utuh string '0081234567'");
assert(!empty($parsedRows[0]['nama_siswa']), "Nama siswa harus terisi");
assert(!empty($parsedRows[0]['nama_ayah']), "Nama ayah harus terpetakan");
echo "✓ 2. Parser Excel berhasil membaca dan mempertahankan leading zeros: " . $parsedRows[0]['nisn'] . " (" . $parsedRows[0]['nama_siswa'] . ")\n";

// 3. Uji Upsert ke Database Buku Induk
$testData = [
    [
        'nisn' => '0091122334',
        'nama_siswa' => 'Ahmad Rabbani Excel Test',
        'nama_kelas' => 'X PPLG 1',
        'jenis_kelamin' => 'L',
        'nis' => 'AF-202688',
        'nik' => '3204991122330001',
        'nama_ayah' => 'Bambang Sudiro',
        'nama_ibu' => 'Halimah Tussadiyah',
        'alamat_jalan' => 'Jl. Pendidikan No. 88',
        'kecamatan' => 'Baleendah',
        'kabupaten_kota' => 'Kab. Bandung'
    ]
];

$upsertResult = BukuInduk::bulkUpsertDapodik($testData);
assert($upsertResult['inserted'] > 0 || $upsertResult['updated'] > 0, "Upsert harus berhasil");
echo "✓ 3. Bulk upsert data siswa ke database sukses (Inserted: {$upsertResult['inserted']}, Updated: {$upsertResult['updated']})\n";

// Verifikasi record
$check = Siswa::findByBarcode('0091122334');
assert($check !== null, "Siswa harus ditemukan di database");
assert($check['nisn'] === '0091122334', "NISN harus presisi string");
$buku = BukuInduk::getBySiswaId((int)$check['id']);
assert($buku !== null && $buku['nama_ibu'] === 'Halimah Tussadiyah', "Data buku induk harus terisi lengkap");
echo "✓ 4. Verifikasi relasi siswa + buku_induk_siswa valid di database\n";

@unlink($tempPath);
echo "=== SEMUA TEST EXCEL DAPODIK LULUS DENGAN SUKSES! ===\n";
