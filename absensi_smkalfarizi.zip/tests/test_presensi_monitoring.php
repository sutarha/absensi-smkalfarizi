<?php
/**
 * Automated test script for:
 * 1. Guru Presensi Mapel (Hadir, Sakit, Izin, Alpa toggle, save, checkin redirect, jam selesai lock)
 * 2. Admin Monitoring Siswa (Rincian Pelajaran Hari Ini & Status Masuk/Tidak Masuk)
 */

$baseUrl = 'http://127.0.0.1:8000';
$cookieFile = sys_get_temp_dir() . '/cookie_test_presensi.txt';
if (file_exists($cookieFile)) unlink($cookieFile);

function curlRequest($url, $postData = null, $customHeaders = []) {
    global $cookieFile;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    if ($postData !== null) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, is_array($postData) ? http_build_query($postData) : $postData);
    }
    if (!empty($customHeaders)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $customHeaders);
    }
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $httpCode, 'body' => $response];
}

echo "=== PENGUJIAN FITUR PRESENSI MAPEL GURU & MONITORING SISWA ===\n\n";

// 1. Login sebagai Guru 1
$res = curlRequest("$baseUrl/login", ['username' => 'guru1', 'password' => 'guru123']);
assert($res['code'] === 200, "Login guru harus 200");
echo "1. Login Guru: SUCCESS (Status: {$res['code']})\n";

// 2. Akses halaman presensi siswa mapel
$res = curlRequest("$baseUrl/guru/presensi/1");
assert($res['code'] === 200, "Akses presensi mapel harus 200");
assert(strpos($res['body'], 'Presensi Siswa KBM') !== false, "Judul presensi siswa KBM harus ada");
assert(strpos($res['body'], 'setStatus(') !== false, "Fungsi setStatus harus ada");
assert(strpos($res['body'], 'updateLiveCounters()') !== false, "Fungsi updateLiveCounters harus ada");
assert(strpos($res['body'], 'Izin') !== false, "Label Izin harus ada");
assert(strpos($res['body'], 'Alpa') !== false, "Label Alpa harus ada");
assert(strpos($res['body'], 'setAllHadir()') !== false, "Fungsi setAllHadir harus ada");
echo "2. Halaman Presensi Siswa Mapel: SUCCESS (Tombol Hadir, Sakit, Izin, Alpa & JS sintaks lengkap)\n";

// 3. Simpan presensi mapel dengan status IZIN dan ALPHA
$postPresensi = [
    'presensi' => [
        1 => 'HADIR',
        2 => 'IZIN',
        3 => 'ALPHA',
        4 => 'SAKIT',
    ],
    'catatan' => [
        1 => '',
        2 => 'Surat izin orang tua',
        3 => 'Tanpa keterangan',
        4 => 'Demam di UKS',
    ]
];
$res = curlRequest("$baseUrl/guru/presensi/1", $postPresensi);
assert($res['code'] === 200, "Simpan presensi mapel harus 200");
assert(strpos($res['body'], 'Presensi siswa berhasil diperbarui!') !== false, "Flash success harus muncul");
echo "3. Simpan Presensi Siswa (Hadir, Izin, Alpa, Sakit): SUCCESS\n";

// 4. Test Check-in API response includes redirect_url
$res = curlRequest("$baseUrl/guru/checkin", [
    'jadwal_id' => 1,
    'bypass_gps' => 1
], [
    'X-Requested-With: XMLHttpRequest',
    'Accept: application/json'
]);
$jsonCheckin = json_decode($res['body'], true);
assert($res['code'] === 200, "Checkin response code 200");
assert(!empty($jsonCheckin['redirect_url']) || !empty($jsonCheckin['sesi_id']), "Checkin harus menyertakan redirect_url / sesi_id");
echo "4. Check-in Otomatis Mengarahkan ke Presensi: SUCCESS (redirect_url: " . ($jsonCheckin['redirect_url'] ?? $jsonCheckin['sesi_id']) . ")\n";

// 5. Login sebagai Admin
unlink($cookieFile);
$res = curlRequest("$baseUrl/login", ['username' => 'admin', 'password' => 'admin123']);
assert($res['code'] === 200, "Login admin harus 200");
echo "5. Login Admin: SUCCESS (Status: {$res['code']})\n";

// 6. Akses halaman Monitoring Siswa
$res = curlRequest("$baseUrl/admin/monitoring/siswa?tanggal=2026-09-07");
assert($res['code'] === 200, "Monitoring siswa harus 200");
assert(strpos($res['body'], 'Monitoring Kehadiran Siswa') !== false, "Judul monitoring harus ada");
assert(strpos($res['body'], 'Rincian Mapel Hari Ini & Status Kehadiran') !== false, "Tab rincian mapel harus ada");
assert(strpos($res['body'], 'Mata Pelajaran Hari Ini') !== false, "Card ringkasan mapel hari ini harus ada");
assert(strpos($res['body'], 'Rincian Pelajaran Hari Ini & Status Kehadiran Siswa') !== false, "Kolom rincian pelajaran siswa harus ada");
assert(strpos($res['body'], 'Masuk (Hadir)') !== false, "Badge Masuk (Hadir) harus ada");
assert(strpos($res['body'], 'Tidak Masuk (Izin)') !== false, "Badge Tidak Masuk (Izin) harus ada");
assert(strpos($res['body'], 'Tidak Masuk (Alpa)') !== false, "Badge Tidak Masuk (Alpa) harus ada");
assert(strpos($res['body'], 'modalDetailSiswa') !== false, "Modal detail siswa harus ada");
echo "6. Halaman Monitoring Siswa Real-Time: SUCCESS (Daftar mata pelajaran hari ini & rincian status masuk/tidak masuk tampil lengkap)\n";

echo "\n===============================================================\n";
echo "SEMUA PENGUJIAN FITUR (PRESENSI MAPEL & MONITORING SISWA) LULUS!\n";
echo "===============================================================\n";
