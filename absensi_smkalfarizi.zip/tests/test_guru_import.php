<?php
// tests/test_guru_import.php - Uji End-to-End Import Guru dari Dapodik
require_once __DIR__ . '/../app/Config/App.php';
require_once __DIR__ . '/../app/Config/Database.php';
require_once __DIR__ . '/../app/Helpers/ExcelHelper.php';
require_once __DIR__ . '/../app/Helpers/DapodikGuruHelper.php';
require_once __DIR__ . '/../app/Models/Guru.php';

use App\Helpers\DapodikGuruHelper;
use App\Models\Guru;

$cookieFile = __DIR__ . '/cookie_guru_test.txt';
if (file_exists($cookieFile)) @unlink($cookieFile);

echo "=== 1. TEST LOGIN ADMIN ===\n";
$ch = curl_init('http://127.0.0.1:8000/login');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(['username' => 'admin', 'password' => 'admin123']));
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
$res = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

assert($code === 200, "Admin login harus HTTP 200");
echo "✓ 1. Admin login berhasil.\n";

echo "=== 2. TEST DOWNLOAD TEMPLATE GURU EXCEL (.XLSX) ===\n";
$ch = curl_init('http://127.0.0.1:8000/admin/guru/download-template');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
curl_setopt($ch, CURLOPT_HEADER, true);
$response = curl_exec($ch);
$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$headers = substr($response, 0, $headerSize);
$body = substr($response, $headerSize);

assert($httpCode === 200, "Download template harus HTTP 200");
assert(strpos($headers, 'template_data_guru_dapodik.xlsx') !== false, "Header harus nama berkas template_data_guru_dapodik.xlsx");
assert(strlen($body) > 1000, "Ukuran template binary harus valid");
echo "✓ 2. Download template Guru Excel (.xlsx) valid (" . strlen($body) . " bytes).\n";

echo "=== 3. TEST UPLOAD BERKAS GURU DAPODIK ASLI VIA MULTIPART ===\n";
$realFile = 'C:\\Users\\USER\\Downloads\\daftar-guru-SMK AL FARIZI BANTARUJEG-2026-09-07 09_31_28.xlsx';

if (file_exists($realFile)) {
    $cFile = new CURLFile($realFile, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', basename($realFile));
    $postData = [
        'file_dapodik' => $cFile,
        'default_password' => 'guru123'
    ];

    $ch = curl_init('http://127.0.0.1:8000/admin/guru/import');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $importRes = curl_exec($ch);
    $importCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    assert($importCode === 200, "Import guru harus sukses");
    assert(strpos($importRes, 'Import Data Guru Dapodik Berhasil') !== false || strpos($importRes, 'guru baru') !== false, "Pesan sukses import harus tampil");
    echo "✓ 3. HTTP Post upload berkas guru Dapodik sukses.\n";

    echo "=== 4. VERIFIKASI DATA GURU DI DATABASE ===\n";
    $guruAlpi = Guru::findByUsername('alpi');
    if (!$guruAlpi) {
        $guruAlpi = Guru::findByUsername('9941772673130332');
    }
    assert($guruAlpi !== null, "Guru Alpi Surya Perdana harus ada di database");
    assert(strpos($guruAlpi['nama_lengkap'], 'ALPI SURYA') !== false, "Nama lengkap harus sesuai");
    assert(!empty($guruAlpi['no_hp']), "Nomor HP harus terisi");
    assert($guruAlpi['tugas_tambahan'] === 'Guru wali', "Tugas tambahan harus sesuai");
    echo "✓ 4. Guru Alpi Surya Perdana terverifikasi: Username=" . $guruAlpi['username'] . ", NUPTK=" . $guruAlpi['nik_nip'] . ", HP=" . $guruAlpi['no_hp'] . "\n";

    $guruEpa = Guru::findByUsername('epa');
    if (!$guruEpa) {
        $guruEpa = Guru::findByUsername('6251764666300033');
    }
    assert($guruEpa !== null, "Guru Epa Parlina harus ada");
    assert($guruEpa['tugas_tambahan'] === 'Wakil Kepala Sekolah Kurikulum', "Tugas tambahan Epa Parlina harus Wakasek Kurikulum");
    echo "✓ 5. Guru Epa Parlina terverifikasi: Tugas=" . $guruEpa['tugas_tambahan'] . ", HP=" . $guruEpa['no_hp'] . "\n";

    echo "=== 5. TEST LOGIN GURU BARU (DAPODIK) ===\n";
    // Uji login menggunakan NUPTK
    $ch = curl_init('http://127.0.0.1:8000/login');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(['username' => $guruAlpi['nik_nip'], 'password' => 'guru123']));
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $loginRes = curl_exec($ch);
    $loginCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    assert(strpos($loginRes, 'Portal Guru KBM') !== false || strpos($loginRes, 'ALPI') !== false, "Guru harus berhasil login dengan NUPTK");
    echo "✓ 6. Guru berhasil login menggunakan NUPTK (" . $guruAlpi['nik_nip'] . ") & password default 'guru123'.\n";
} else {
    echo "File Dapodik tidak ditemukan di lokasi lokal, lewati tes file lokal.\n";
}

@unlink($cookieFile);
echo "=== SEMUA TEST IMPORT GURU DAPODIK BERHASIL DENGAN SUKSES! ===\n";
