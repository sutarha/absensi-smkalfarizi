<?php
/**
 * Test Suite: Real-Time Endpoints Validation
 */
require_once __DIR__ . '/../app/Config/Database.php';
require_once __DIR__ . '/../app/Config/App.php';
require_once __DIR__ . '/../app/Models/Guru.php';
require_once __DIR__ . '/../app/Models/PresensiGerbang.php';
require_once __DIR__ . '/../app/Models/PresensiGerbangGuru.php';
require_once __DIR__ . '/../app/Models/SesiMengajar.php';
require_once __DIR__ . '/../app/Models/PresensiMapel.php';

\App\Config\App::init();

echo "=== TEST SUITE: REAL-TIME ENDPOINTS & LIVE SYNC ===\n\n";

// 1. Test Model PresensiGerbang::getRecentScans
echo "1. Testing PresensiGerbang::getRecentScans()...\n";
$scans = \App\Models\PresensiGerbang::getRecentScans(date('Y-m-d'), 10);
assert(is_array($scans), "Recent scans must be array");
echo "   [PASS] Found " . count($scans) . " recent scans for today.\n";

// 2. Test PresensiGerbangGuru::getByDate
echo "2. Testing PresensiGerbangGuru::getByDate()...\n";
$guruList = \App\Models\PresensiGerbangGuru::getByDate(date('Y-m-d'));
assert(is_array($guruList), "Guru list must be array");
echo "   [PASS] Found " . count($guruList) . " teachers in daily gate attendance log.\n";

// 3. Test HTTP Endpoints via cURL on localhost:8000
$baseUrl = 'http://localhost:8000';
$cookieFile = sys_get_temp_dir() . '/cookie_realtime_test.txt';
@unlink($cookieFile);

function httpReq(string $url, string $method = 'GET', array $data = [], string $cookie = ''): array {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    }
    $body = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['status' => $status, 'body' => $body];
}

// 4. Test Piket Live Feed
echo "3. Testing /piket/live-feed Endpoint...\n";
// Login as piket
$loginPiket = httpReq("$baseUrl/login", 'POST', ['username' => 'guru1', 'password' => 'guru123'], $cookieFile);
$piketFeed = httpReq("$baseUrl/piket/live-feed", 'GET', [], $cookieFile);
$jsonPiket = json_decode($piketFeed['body'], true);
assert($piketFeed['status'] === 200, "Piket feed status must be 200");
assert($jsonPiket['success'] === true, "Piket feed success must be true");
assert(isset($jsonPiket['counters']['total_datang']), "Piket counters total_datang must exist");
assert(isset($jsonPiket['recent_scans']), "recent_scans must exist");
echo "   [PASS] Piket Live Feed OK! (Server Time: {$jsonPiket['server_time']}, Datang: {$jsonPiket['counters']['total_datang']})\n";

// 5. Test Guru Live Status
echo "4. Testing /guru/live-status Endpoint...\n";
$guruLive = httpReq("$baseUrl/guru/live-status", 'GET', [], $cookieFile);
$jsonGuru = json_decode($guruLive['body'], true);
assert($guruLive['status'] === 200, "Guru live status must be 200");
assert($jsonGuru['success'] === true, "Guru live success must be true");
assert(isset($jsonGuru['is_pulang_open']), "is_pulang_open must exist");
assert(isset($jsonGuru['jam_pulang_mulai']), "jam_pulang_mulai must exist");
assert(isset($jsonGuru['jadwal_list']), "jadwal_list must exist");
echo "   [PASS] Guru Live Status OK! (Pulang Open: " . ($jsonGuru['is_pulang_open'] ? 'YES' : 'NO') . ", Pulang At: {$jsonGuru['jam_pulang_mulai']})\n";

// 6. Test Admin Live Monitoring Endpoints
echo "5. Testing /admin/monitoring/guru-live and /admin/monitoring/siswa-live...\n";
$adminCookie = sys_get_temp_dir() . '/cookie_admin_realtime.txt';
@unlink($adminCookie);
$loginAdmin = httpReq("$baseUrl/login", 'POST', ['username' => 'admin', 'password' => 'admin123'], $adminCookie);

$adminGuruLive = httpReq("$baseUrl/admin/monitoring/guru-live", 'GET', [], $adminCookie);
$jsonAdminGuru = json_decode($adminGuruLive['body'], true);
assert($adminGuruLive['status'] === 200, "Admin guru live status must be 200");
assert($jsonAdminGuru['success'] === true, "Admin guru live success must be true");
assert(isset($jsonAdminGuru['counters']['di_sekolah']), "Admin guru counters must have di_sekolah");
assert(isset($jsonAdminGuru['gerbang_list']), "gerbang_list must exist");
assert(isset($jsonAdminGuru['sessions']), "sessions must exist");
echo "   [PASS] Admin Monitoring Guru Live OK! (Guru di sekolah: {$jsonAdminGuru['counters']['di_sekolah']}, Sesi KBM: {$jsonAdminGuru['counters']['total_sesi']})\n";

$adminSiswaLive = httpReq("$baseUrl/admin/monitoring/siswa-live", 'GET', [], $adminCookie);
$jsonAdminSiswa = json_decode($adminSiswaLive['body'], true);
assert($adminSiswaLive['status'] === 200, "Admin siswa live status must be 200");
assert($jsonAdminSiswa['success'] === true, "Admin siswa live success must be true");
assert(isset($jsonAdminSiswa['counters']['total_siswa']), "Admin siswa counters must have total_siswa");
assert(isset($jsonAdminSiswa['ketuntasan']), "ketuntasan must exist");
echo "   [PASS] Admin Monitoring Siswa Live OK! (Total Siswa: {$jsonAdminSiswa['counters']['total_siswa']}, Datang: {$jsonAdminSiswa['counters']['total_datang']}, Belum Pulang: {$jsonAdminSiswa['counters']['total_belum_pulang']})\n";

echo "\n=========================================================\n";
echo "SEMUA FITUR REAL-TIME BERJALAN SEMPURNA DAN TERVERIFIKASI!\n";
echo "=========================================================\n";
