<?php
try {
    $dsn = "mysql:host=127.0.0.1;port=3306;dbname=db_presensi_smkalfarizi;charset=utf8mb4";
    $db = new PDO($dsn, 'root', '');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $stmt = $db->query("UPDATE siswa SET tanggal_lahir = '2005-01-01' WHERE tanggal_lahir IS NULL");
    echo "Berhasil update " . $stmt->rowCount() . " siswa dengan tanggal lahir default (2005-01-01).\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
